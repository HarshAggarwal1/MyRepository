//package com.example.snakeandladder;
//
//import javafx.application.Application;
//import javafx.scene.control.Cell;
//import javafx.scene.image.ImageView;
//import javafx.scene.image.Image;
//import javafx.scene.Stage;
//import javafx.scene.layout.GridPane;
//import javafx.scene.layout.StackPane;
//
//public class Rough1 extends Application{
//
//    int rows =10;
//    int columns =10;
//    double width = 800;
//    double height = 800;
// // "file:\\C:\\Users\\harsh\\Desktop\\AP Project\\SnakeAndLadder\\src\\main\\java\\com\\example\\snakeandladder\\board.jpg"
//    Imageview image = new ImageView(new Image("file:\\C:\\Users\\harsh\\Desktop\\AP Project\\SnakeAndLadder\\src\\main\\java\\com\\example\\snakeandladder\\board.jpg"));
//
//    @Override
//    public void start(Stage stage){
//        StackPane root = new StackPane();
//
//
//        GridPane grid = new GridPane(10,10,0,0);
//
//        for(int i =0;i<10;i++){
//            for(int j=0;j<10;j++){
//                Cell cell = new Cell(10,10);
//
//                grid.add(cell,10,10);
//            }
//        }
//
//
//
//    }
//
//
//}
