package com.example.snakeandladder;

import javafx.animation.PathTransition;
import javafx.animation.TranslateTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.image.Image;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.*;
import javafx.util.Duration;

public class MainController {
    @FXML
    private Rectangle myDice;

    Player player1;
    Player player2;

    public void initialize() {
        this.player1 = new Player(Player1, Main.board, myDice);
        this.player2 = new Player(Player2, Main.board, myDice);
    }

    public void playerOneClick(ActionEvent event) {
        if (this.player1.isLocked()) {
            int diceNum = Integer.parseInt(this.player1.getDiceNum());
            if (diceNum == 6) {
                double posX = this.player1.getBoard().getBoard()[0][0].getPosX();
                double posY = this.player1.getBoard().getBoard()[0][0].getPosY();
                this.player1.unlock();
                this.player1.movePlayerOnTile(posX, posY, 1);
            }
            if (this.player1.getTile().getType().equals("LadderTail")) {
                double posX = this.player1.getCurrPosX();
                double posY = this.player1.getCurrPosY();
                int topTileNum = this.player1.getTileNum();
                for (int i = 0; i < 8; i++) {
                    if (Main.laddersList[i].getBottomTileNum() == this.player1.getTileNum()) {
                        posX = Main.laddersList[i].getTopPosX();
                        posY = Main.laddersList[i].getTopPosY();
                        topTileNum = Main.laddersList[i].getTopTileNum();
                        break;
                    }
                }
                this.player1.movePlayerOnTile(posX, posY, topTileNum);
            }
            return;
        }
        if (!this.player1.isCompleted()) {
            int diceNum = Integer.parseInt(this.player1.getDiceNum());
            int currTile = this.player1.getTileNum();
            int nextTile = currTile + diceNum;
            if (nextTile > 100) {
                return;
            }
            while (currTile < nextTile) {
                int i = currTile / 10;
                int j;
                if ((currTile + 1) % 10 == 0) {
                    j = 9;
                }
                else {
                    j = ((currTile + 1) % 10) - 1;
                }
                double posX = this.player1.getBoard().getBoard()[i][j].getPosX();
                double posY = this.player1.getBoard().getBoard()[i][j].getPosY();
                this.player1.movePlayerOnTile(posX, posY, nextTile);
                currTile++;
            }
            if (this.player1.getTile().getType().equals("LadderTail")) {
                double posX = this.player1.getCurrPosX();
                double posY = this.player1.getCurrPosY();
                int topTileNum = this.player1.getTileNum();
                for (int i = 0; i < 8; i++) {
                    if (Main.laddersList[i].getBottomTileNum() == this.player1.getTileNum()) {
                        posX = Main.laddersList[i].getTopPosX();
                        posY = Main.laddersList[i].getTopPosY();
                        topTileNum = Main.laddersList[i].getTopTileNum();
                        break;
                    }
                }
                this.player1.movePlayerOnTile(posX, posY, topTileNum);
            }
            else if (this.player1.getTile().getType().equals("SnakeHead")) {
                double posX = this.player1.getCurrPosX();
                double posY = this.player1.getCurrPosY();
                int tailTileNum = this.player1.getTileNum();
                for (int i = 0; i < 7; i++) {
                    if (Main.snakesList[i].getHeadTileNum() == this.player1.getTileNum()) {
                        posX = Main.snakesList[i].getTailPosX();
                        posY = Main.snakesList[i].getTailPosY();
                        tailTileNum = Main.snakesList[i].getTailTileNum();
                        break;
                    }
                }
                this.player1.movePlayerOnTile(posX, posY, tailTileNum);
            }
            if (this.player1.getTileNum() == 100) {
                this.player1.setCompleted();
            }
        }
    }
    // --------------------------------------- Players -----------------------------------------------------------------
    @FXML
    private Circle Player1;
    @FXML
    private Circle Player2;
    // -----------------------------------------------------------------------------------------------------------------
    @FXML
    private Rectangle arrowOne;
}
