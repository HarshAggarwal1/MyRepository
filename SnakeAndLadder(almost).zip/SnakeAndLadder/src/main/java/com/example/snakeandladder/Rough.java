package com.example.snakeandladder;
//
//import java.io.File;
//
//public class Rough {
//
//    Random rand = new Random();
//
//    @FXML
//    private ImageView diceImage;
//
//    @FXML
//    private Button score;
//
//    @FXML
//    void roll(ActionEvent event){
//        score.setDisable(true);
//
//        Thread thread = new Thread(){
//            public void run(){
//                System.out.println("thread running");
//                try{
//                    for(int i=0;i<15;i++){
//                        File file = new File("DICE "+(rand.nextInt(6)+1)+".jpeg");
//                        diceImage.setImage(new Image(file.toURI().toString()));
//                        Thread.sleep(50);
//                    }
//                    score.setDisable(false);
//                } catch (InterruptedException e) {
//                    e.printStackTrace();
//                }
//            }
//        };
//
//        thread.start();
//
//
//    }
//}